""" Optional questions for Lab 05 """

from lab05 import *